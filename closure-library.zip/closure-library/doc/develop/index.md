<!-- Documentation licensed under CC BY 4.0 -->
<!-- License available at https://creativecommons.org/licenses/by/4.0/ -->

---
title: Develop with Closure
section: develop
layout: article
---


# Develop with Closure

This section contains information pertaining to the development of applications
with the Closure Library.

*   [Getting started](./get-started)
*   [JSConformance configuration documentation](./conformance_rules)

