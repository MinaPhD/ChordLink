<!-- Documentation licensed under CC BY 4.0 -->
<!-- License available at https://creativecommons.org/licenses/by/4.0/ -->

# Closure Generated API Docs

This is the generated documentation for the Closure Library
repository at
[github.com/google/closure-library](http://github.com/google/closure-library).

Use the "Search" bar above to find the Closure API you're looking for. For
example, `goog.array`. Alternatively, explore the APIs using the drop-down
menu in the top-left corner.

The documentation was produced using
[github.com/jleyba/js-dossier](http://github.com/jleyba/js-dossier)
